'use strict';

angular.module('startUpApp')
  .service('packages', function () {
    // AngularJS will instantiate a singleton by calling "new" on this function
  });
